import { configureStore } from '@reduxjs/toolkit';
import authReducer from './authSlice';
import characterReducer from './characterSlice';

export default configureStore({
  reducer: {
    auth: authReducer,
    characters: characterReducer,
  },
});
