import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';

export const fetchCharacters = createAsyncThunk('characters/fetchCharacters', async (page) => {
  const response = await axios.get(`https://swapi.dev/api/people/?page=${page}`);
  return response.data.results;
});

const characterSlice = createSlice({
  name: 'characters',
  initialState: { list: [], status: null },
  reducers: {},
  extraReducers: {
    [fetchCharacters.pending]: (state) => {
      state.status = 'loading';
    },
    [fetchCharacters.fulfilled]: (state, action) => {
      state.status = 'succeeded';
      state.list = action.payload;
    },
    [fetchCharacters.rejected]: (state) => {
      state.status = 'failed';
    },
  },
});

export default characterSlice.reducer;
